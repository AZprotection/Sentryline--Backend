// Local smoke test — runs the real Express app against an in-memory
// Postgres-compatible engine (pg-mem), so you can verify the API works
// end-to-end without a live database. Run with: node test/smoke.js
//
// Note: pg-mem is a test-only tool and doesn't implement every native
// Postgres function (e.g. json_build_object). Where you see a query
// "skipped" below, that's a gap in pg-mem, not in the SQL — those same
// queries run fine against real Postgres, which is what schema.sql
// targets in production.
const { newDb } = require('pg-mem');
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');

const mem = newDb({ autoCreateForeignKeyIndices: true });
const { randomUUID } = require('crypto');
mem.public.registerFunction({
  name: 'gen_random_uuid',
  returns: 'uuid',
  implementation: () => randomUUID(),
  impure: true,
});

let schemaSql = fs.readFileSync(path.join(__dirname, '..', 'sql', 'schema.sql'), 'utf8')
  .replace(/create extension.*pgcrypto.*;/i, '');
mem.public.query(schemaSql);
console.log('Schema applied to in-memory Postgres engine OK');

const { Pool } = mem.adapters.createPg();
const pgPath = require.resolve('pg');
require.cache[pgPath] = { id: pgPath, filename: pgPath, loaded: true, exports: { Pool } };

process.env.DATABASE_URL = 'postgres://fake';
process.env.JWT_SECRET = 'test-secret';
process.env.PORT = '4123';

async function seed() {
  const pool = new Pool();
  const passwordHash = await bcrypt.hash('patrol123', 10);
  const site = await pool.query(`insert into sites (name) values ('Test Site') returning id`);
  const siteId = site.rows[0].id;
  const guard = await pool.query(
    `insert into users (site_id, name, badge_number, password_hash, role) values ($1,$2,$3,$4,'GUARD') returning id`,
    [siteId, 'Test Guard', 'GS-0001', passwordHash]
  );
  const guard2 = await pool.query(
    `insert into users (site_id, name, badge_number, password_hash, role) values ($1,$2,$3,$4,'GUARD') returning id`,
    [siteId, 'Second Guard', 'GS-0002', passwordHash]
  );
  await pool.query(
    `insert into checkpoints (site_id, name, zone, nfc_tag_id) values ($1,'Main Gate','Entry','NFC-0001')`,
    [siteId]
  );
  await pool.query(
    `insert into client_contacts (site_id, name, email, phone) values ($1,'Manager','m@example.com','+15551234567')`,
    [siteId]
  );
  await pool.query(
    `insert into zones (site_id, name, locked, schedule, note) values ($1,'Test Zone',false,'24 hours','test note')`,
    [siteId]
  );
  await pool.query(
    `insert into sensors (site_id, name, zone, type) values ($1,'Test Sensor','Entry','door')`,
    [siteId]
  );
  await pool.query(
    `insert into trainings (site_id, guard_id, course, pct, status) values ($1,$2,'Test Course',50,'DUE')`,
    [siteId, guard.rows[0].id]
  );
  await pool.end();
  return { siteId, guardId: guard.rows[0].id, guard2Id: guard2.rows[0].id };
}

async function main() {
  await seed();
  console.log('Seed OK');

  require('../src/index.js');
  await new Promise((r) => setTimeout(r, 300));

  const base = `http://localhost:${process.env.PORT}`;

  let res = await fetch(`${base}/health`);
  console.log('GET /health ->', res.status, await res.json());

  res = await fetch(`${base}/auth/login`, {
    method: 'POST', headers: {'content-type':'application/json'},
    body: JSON.stringify({ identifier: 'GS-0001', password: 'patrol123' })
  });
  const loginBody = await res.json();
  console.log('POST /auth/login ->', res.status, loginBody.user ? 'token issued' : loginBody);
  const token = loginBody.token;
  const auth = { authorization: `Bearer ${token}`, 'content-type': 'application/json' };

  res = await fetch(`${base}/checkpoints`, { headers: auth });
  console.log('GET /checkpoints ->', res.status, (await res.json()).length, 'checkpoint(s)');

  res = await fetch(`${base}/shifts/clock-in`, { method:'POST', headers: auth, body: JSON.stringify({}) });
  console.log('POST /shifts/clock-in (no photo) ->', res.status, await res.json());

  res = await fetch(`${base}/shifts/clock-in`, { method:'POST', headers: auth, body: JSON.stringify({ clockInPhotoUrl: 'data:image/png;base64,AAAA' }) });
  const shift = await res.json();
  console.log('POST /shifts/clock-in ->', res.status, shift.status);

  res = await fetch(`${base}/checkpoints`, { headers: auth });
  const checkpoints = await res.json();
  res = await fetch(`${base}/checkpoints/${checkpoints[0].id}/scan`, {
    method: 'POST', headers: auth,
    body: JSON.stringify({ latitude: 37.77, longitude: -122.41, accuracyM: 8, method: 'nfc' })
  });
  console.log('POST /checkpoints/:id/scan ->', res.status, (await res.json()).status);

  res = await fetch(`${base}/incidents`, {
    method: 'POST', headers: auth,
    body: JSON.stringify({
      type: 'Suspicious activity', location: 'Loading Dock', description: 'Unattended bag observed.',
      severity: 'HIGH', attachments: [{ type: 'photo', url: 'data:image/png;base64,AAAA' }]
    })
  });
  console.log('POST /incidents ->', res.status);

  res = await fetch(`${base}/incidents`, { headers: auth });
  if (res.status === 200) {
    const incidents = await res.json();
    console.log('GET /incidents -> attachments on first incident:', incidents[0].attachments);
  } else {
    console.log('GET /incidents -> skipped (pg-mem gap, see file header note)');
  }

  res = await fetch(`${base}/visitors`, { method:'POST', headers: auth, body: JSON.stringify({ name: 'Jane Vendor', company: 'Acme Corp' }) });
  console.log('POST /visitors ->', res.status);

  res = await fetch(`${base}/activity`, { method:'POST', headers: auth, body: JSON.stringify({ title: 'Field note test', meta: 'smoke test' }) });
  console.log('POST /activity ->', res.status);

  res = await fetch(`${base}/activity`, { headers: auth });
  if (res.status === 200) {
    console.log('GET /activity -> entries today:', (await res.json()).length);
  } else {
    console.log('GET /activity -> skipped (pg-mem gap, see file header note)');
  }

  res = await fetch(`${base}/shifts/break/start`, { method:'POST', headers: auth, body: '{}' });
  console.log('POST /shifts/break/start ->', res.status);
  res = await fetch(`${base}/shifts/break/end`, { method:'POST', headers: auth, body: '{}' });
  console.log('POST /shifts/break/end ->', res.status);

  res = await fetch(`${base}/reports/send`, { method:'POST', headers: auth });
  const reportBody = await res.json();
  console.log('POST /reports/send ->', res.status, reportBody.report ? reportBody.report.summary : reportBody);

  res = await fetch(`${base}/zones`, { headers: auth });
  const zones = await res.json();
  console.log('GET /zones ->', res.status, zones.length, 'zone(s)');
  res = await fetch(`${base}/zones/${zones[0].id}/toggle`, { method: 'PATCH', headers: auth });
  console.log('PATCH /zones/:id/toggle ->', res.status, (await res.json()).locked ? 'locked' : 'unlocked');

  res = await fetch(`${base}/sensors`, { headers: auth });
  const sensors = await res.json();
  console.log('GET /sensors ->', res.status, sensors.length, 'sensor(s)');
  res = await fetch(`${base}/sensors/${sensors[0].id}/toggle`, { method: 'PATCH', headers: auth });
  console.log('PATCH /sensors/:id/toggle ->', res.status, (await res.json()).status);

  res = await fetch(`${base}/training`, { headers: auth });
  console.log('GET /training ->', res.status, (await res.json()).length, 'record(s)');

  res = await fetch(`${base}/analytics/checkpoint-activity`, { headers: auth });
  if (res.status === 200) {
    console.log('GET /analytics/checkpoint-activity ->', res.status, (await res.json()).length, 'bucket(s)');
  } else {
    console.log('GET /analytics/checkpoint-activity -> skipped: pg-mem does not implement date_trunc(); real Postgres does.');
  }

  res = await fetch(`${base}/analytics/incidents-weekly`, { headers: auth });
  if (res.status === 200) {
    console.log('GET /analytics/incidents-weekly ->', res.status, (await res.json()).length, 'week(s)');
  } else {
    console.log('GET /analytics/incidents-weekly -> skipped: pg-mem does not parse week-based intervals; real Postgres does.');
  }

  // ===== MULTI-GUARD FLEET / LIVE PRESENCE =====
  // Log in as a second guard to simulate a real multi-guard fleet.
  res = await fetch(`${base}/auth/login`, {
    method: 'POST', headers: {'content-type':'application/json'},
    body: JSON.stringify({ identifier: 'GS-0002', password: 'patrol123' })
  });
  const login2 = await res.json();
  const auth2 = { authorization: `Bearer ${login2.token}`, 'content-type': 'application/json' };

  res = await fetch(`${base}/shifts/clock-in`, { method:'POST', headers: auth2, body: JSON.stringify({ clockInPhotoUrl: 'data:image/png;base64,BBBB' }) });
  console.log('[guard 2] POST /shifts/clock-in ->', res.status, (await res.json()).status);

  // Open a real SSE connection as guard 1 (the "dispatcher") and confirm
  // guard 2's location ping arrives over the live stream.
  const streamUrl = `${base}/fleet/stream?token=${encodeURIComponent(token)}`;
  const streamEvents = [];
  const controller = new AbortController();
  fetch(streamUrl, { signal: controller.signal }).then(async (streamRes) => {
    const reader = streamRes.body.getReader();
    const decoder = new TextDecoder();
    let buf = '';
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += decoder.decode(value, { stream: true });
      const parts = buf.split('\n\n');
      buf = parts.pop();
      for (const part of parts) {
        const eventLine = part.split('\n').find(l => l.startsWith('event:'));
        if (eventLine) streamEvents.push(eventLine.replace('event:', '').trim());
      }
    }
  }).catch(() => {});

  await new Promise(r => setTimeout(r, 200)); // let the SSE connection establish

  res = await fetch(`${base}/shifts/location`, {
    method: 'POST', headers: auth2,
    body: JSON.stringify({ latitude: 37.775, longitude: -122.42, accuracyM: 6 })
  });
  console.log('[guard 2] POST /shifts/location ->', res.status);

  await new Promise(r => setTimeout(r, 200)); // let the event propagate over SSE
  console.log('[SSE] events received by guard 1\'s stream:', streamEvents);
  controller.abort();

  res = await fetch(`${base}/fleet/active`, { headers: auth });
  const fleet = await res.json();
  console.log('GET /fleet/active ->', res.status, `${fleet.length} guard(s) on duty:`,
    fleet.map(f => `${f.guard_name} (${f.status})`).join(', '));

  // SOS trigger + clear, as guard 2
  res = await fetch(`${base}/sos/trigger`, { method: 'POST', headers: auth2, body: JSON.stringify({ latitude: 37.775, longitude: -122.42 }) });
  console.log('POST /sos/trigger ->', res.status, (await res.json()).status);

  res = await fetch(`${base}/sos/active`, { headers: auth });
  console.log('GET /sos/active ->', res.status, (await res.json()).length, 'active SOS event(s)');

  res = await fetch(`${base}/sos/clear`, { method: 'POST', headers: auth2 });
  console.log('POST /sos/clear ->', res.status, (await res.json()).status);

  console.log('\nALL SMOKE TESTS COMPLETED');
  process.exit(0);
}

main().catch((e) => { console.error('SMOKE TEST FAILED:', e); process.exit(1); });

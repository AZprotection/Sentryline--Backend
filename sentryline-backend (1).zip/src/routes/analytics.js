const express = require('express');
const { query } = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth);

// GET /analytics/checkpoint-activity — raw scan counts per zone per hour,
// last 24 hours. The frontend buckets this into its heat map grid.
router.get('/checkpoint-activity', async (req, res) => {
  const { rows } = await query(
    `select c.zone,
       date_trunc('hour', cs.created_at) as hour,
       count(*) as count
     from checkpoint_scans cs
     join checkpoints c on c.id = cs.checkpoint_id
     where c.site_id = $1 and cs.created_at > now() - interval '1 day'
     group by c.zone, hour
     order by hour asc`,
    [req.user.siteId]
  );
  res.json(rows);
});

// GET /analytics/incidents-weekly — incident counts for the last 5 weeks
router.get('/incidents-weekly', async (req, res) => {
  const { rows } = await query(
    `select date_trunc('week', created_at) as week, count(*) as count
     from incidents
     where site_id = $1 and created_at > now() - interval '5 weeks'
     group by week
     order by week asc`,
    [req.user.siteId]
  );
  res.json(rows);
});

module.exports = router;

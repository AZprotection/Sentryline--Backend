const express = require('express');
const { query } = require('../db');
const { requireAuth } = require('../middleware/auth');
const { CONSENT_POLICY_VERSION } = require('../policyVersion');

const router = express.Router();
router.use(requireAuth);

router.get('/status', async (req, res) => {
  const { rows } = await query(
    `select * from consents where user_id = $1 and policy_version = $2 order by accepted_at desc limit 1`,
    [req.user.userId, CONSENT_POLICY_VERSION]
  );
  res.json({ currentVersion: CONSENT_POLICY_VERSION, accepted: !!rows[0], acceptedAt: rows[0]?.accepted_at || null });
});

router.post('/accept', async (req, res) => {
  const { rows } = await query(
    `insert into consents (user_id, policy_version, ip_address) values ($1,$2,$3) returning *`,
    [req.user.userId, CONSENT_POLICY_VERSION, req.ip]
  );
  res.status(201).json(rows[0]);
});

module.exports = router;

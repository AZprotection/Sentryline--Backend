const express = require('express');
const { query } = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth);

router.get('/', async (req, res) => {
  const { rows } = await query(
    `select * from visitors where site_id = $1 order by check_in_at desc`,
    [req.user.siteId]
  );
  res.json(rows);
});

router.post('/', async (req, res) => {
  const { name, company, host, purpose, vehiclePlate, idChecked } = req.body || {};
  if (!name) return res.status(400).json({ error: 'name is required' });

  const { rows } = await query(
    `insert into visitors (site_id, name, company, host, purpose, vehicle_plate, id_checked)
     values ($1,$2,$3,$4,$5,$6,$7) returning *`,
    [req.user.siteId, name, company || null, host || null, purpose || null, vehiclePlate || null, !!idChecked]
  );

  await query(
    `insert into activity_log_entries (site_id, guard_id, type, title, meta)
     values ($1,$2,'visitor',$3,$4)`,
    [req.user.siteId, req.user.userId, `Visitor checked in: ${name}`, company || null]
  );

  res.status(201).json(rows[0]);
});

router.post('/:id/check-out', async (req, res) => {
  const { rows } = await query(
    `update visitors set check_out_at = now() where id = $1 and site_id = $2 returning *`,
    [req.params.id, req.user.siteId]
  );
  if (!rows[0]) return res.status(404).json({ error: 'Visitor not found' });
  res.json(rows[0]);
});

module.exports = router;

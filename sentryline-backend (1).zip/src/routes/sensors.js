const express = require('express');
const { query } = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth);

router.get('/', async (req, res) => {
  const { rows } = await query(`select * from sensors where site_id = $1 order by name asc`, [req.user.siteId]);
  res.json(rows);
});

router.post('/', requireRole('ADMIN'), async (req, res) => {
  const { name, zone, type } = req.body || {};
  if (!name || !zone || !type) return res.status(400).json({ error: 'name, zone, and type are required' });
  const { rows } = await query(
    `insert into sensors (site_id, name, zone, type) values ($1,$2,$3,$4) returning *`,
    [req.user.siteId, name, zone, type]
  );
  res.status(201).json(rows[0]);
});

// PATCH /sensors/:id/toggle — flips normal/triggered and logs it
router.patch('/:id/toggle', async (req, res) => {
  const current = await query(`select * from sensors where id = $1 and site_id = $2`, [req.params.id, req.user.siteId]);
  const sensor = current.rows[0];
  if (!sensor) return res.status(404).json({ error: 'Sensor not found' });

  const nextStatus = sensor.status === 'normal' ? 'triggered' : 'normal';
  const { rows } = await query(
    `update sensors set status = $1, updated_at = now() where id = $2 returning *`,
    [nextStatus, sensor.id]
  );

  if (nextStatus === 'triggered') {
    await query(
      `insert into activity_log_entries (site_id, guard_id, type, title, meta) values ($1,$2,'sensor',$3,$4)`,
      [req.user.siteId, req.user.userId, `Sensor triggered: ${sensor.name}`, sensor.zone]
    );
  }

  res.json(rows[0]);
});

module.exports = router;

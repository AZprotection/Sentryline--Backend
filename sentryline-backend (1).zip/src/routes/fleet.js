const express = require('express');
const { query } = require('../db');
const { requireAuth, requireAuthViaQueryOrHeader } = require('../middleware/auth');
const { subscribe } = require('../pubsub');

const router = express.Router();

// GET /fleet/active — every guard currently clocked on or on break, with
// their last known location and today's checkpoint progress. This is
// what powers the Command Portal's live map and guard status list.
router.get('/active', requireAuth, async (req, res) => {
  const totalResult = await query(
    `select count(*) as total from checkpoints where site_id = $1 and active = true`,
    [req.user.siteId]
  );
  const checkpointsTotal = Number(totalResult.rows[0].total);

  const { rows } = await query(
    `select s.id as shift_id, s.guard_id, u.name as guard_name, u.badge_number,
       s.status, s.clock_in_at, s.last_latitude, s.last_longitude, s.last_accuracy_m, s.last_location_at,
       count(cs.id) filter (where cs.status = 'DONE') as checkpoints_done
     from shifts s
     join users u on u.id = s.guard_id
     left join checkpoint_scans cs on cs.shift_id = s.id
     where s.site_id = $1 and s.status in ('ON','BREAK')
     group by s.id, s.guard_id, u.name, u.badge_number, s.status, s.clock_in_at,
       s.last_latitude, s.last_longitude, s.last_accuracy_m, s.last_location_at
     order by s.clock_in_at asc`,
    [req.user.siteId]
  );

  res.json(rows.map(r => ({ ...r, checkpoints_total: checkpointsTotal })));
});

// GET /fleet/stream — Server-Sent Events. Every location ping, checkpoint
// scan, clock in/out, incident, and SOS on this site pushes an event here
// in real time, so a dispatcher's screen updates without polling.
router.get('/stream', requireAuthViaQueryOrHeader, (req, res) => {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
  });
  res.write('retry: 3000\n\n');

  const unsubscribe = subscribe(req.user.siteId, (event) => {
    res.write(`event: ${event.type}\ndata: ${JSON.stringify(event.payload)}\n\n`);
  });

  const heartbeat = setInterval(() => res.write(': ping\n\n'), 25000);

  req.on('close', () => {
    clearInterval(heartbeat);
    unsubscribe();
  });
});

module.exports = router;

const express = require('express');
const { query } = require('../db');
const { requireAuth } = require('../middleware/auth');
const { publish } = require('../pubsub');
const { CONSENT_POLICY_VERSION } = require('../policyVersion');
const { checkGeofences } = require('../services/geofence');

const router = express.Router();
router.use(requireAuth);

// GET /shifts/current — the caller's open shift, if any
router.get('/current', async (req, res) => {
  const { rows } = await query(
    `select * from shifts where guard_id = $1 and status in ('ON','BREAK') order by created_at desc limit 1`,
    [req.user.userId]
  );
  res.json(rows[0] || null);
});

// POST /shifts/clock-in  { clockInPhotoUrl }  — photo verification is required by the client
router.post('/clock-in', async (req, res) => {
  const { clockInPhotoUrl } = req.body || {};
  if (!clockInPhotoUrl) {
    return res.status(400).json({ error: 'A verification photo is required before clocking in' });
  }

  const consent = await query(
    `select 1 from consents where user_id = $1 and policy_version = $2`,
    [req.user.userId, CONSENT_POLICY_VERSION]
  );
  if (!consent.rows.length) {
    return res.status(403).json({ error: 'consent_required', message: 'You must accept GPS and photo tracking disclosure before clocking in' });
  }

  const open = await query(
    `select id from shifts where guard_id = $1 and status in ('ON','BREAK')`,
    [req.user.userId]
  );
  if (open.rows.length) return res.status(409).json({ error: 'Already clocked in' });

  const { rows } = await query(
    `insert into shifts (site_id, guard_id, status, clock_in_at, clock_in_photo_url)
     values ($1,$2,'ON', now(), $3) returning *`,
    [req.user.siteId, req.user.userId, clockInPhotoUrl]
  );

  await query(
    `insert into activity_log_entries (site_id, guard_id, type, title) values ($1,$2,'attendance',$3)`,
    [req.user.siteId, req.user.userId, `${req.user.name} clocked in (ID verified)`]
  );

  publish(req.user.siteId, { type: 'fleet', payload: { guardId: req.user.userId, guardName: req.user.name, status: 'ON', event: 'clock-in' } });
  res.status(201).json(rows[0]);
});

router.post('/clock-out', async (req, res) => {
  const open = await query(
    `select * from shifts where guard_id = $1 and status in ('ON','BREAK') order by created_at desc limit 1`,
    [req.user.userId]
  );
  const shift = open.rows[0];
  if (!shift) return res.status(409).json({ error: 'No open shift' });

  const { rows } = await query(
    `update shifts set status='OFF', clock_out_at = now() where id = $1 returning *`,
    [shift.id]
  );

  await query(
    `insert into activity_log_entries (site_id, guard_id, type, title) values ($1,$2,'attendance',$3)`,
    [req.user.siteId, req.user.userId, `${req.user.name} clocked out`]
  );

  publish(req.user.siteId, { type: 'fleet', payload: { guardId: req.user.userId, guardName: req.user.name, status: 'OFF', event: 'clock-out' } });
  res.json(rows[0]);
});

router.post('/break/start', async (req, res) => {
  const open = await query(
    `select * from shifts where guard_id = $1 and status = 'ON' order by created_at desc limit 1`,
    [req.user.userId]
  );
  const shift = open.rows[0];
  if (!shift) return res.status(409).json({ error: 'Not currently on shift' });

  await query(`update shifts set status='BREAK' where id = $1`, [shift.id]);
  const { rows } = await query(
    `insert into breaks (shift_id, started_at) values ($1, now()) returning *`,
    [shift.id]
  );

  await query(
    `insert into activity_log_entries (site_id, guard_id, type, title) values ($1,$2,'break',$3)`,
    [req.user.siteId, req.user.userId, `${req.user.name} started a break`]
  );

  publish(req.user.siteId, { type: 'fleet', payload: { guardId: req.user.userId, guardName: req.user.name, status: 'BREAK', event: 'break-start' } });
  res.status(201).json(rows[0]);
});

router.post('/break/end', async (req, res) => {
  const shiftResult = await query(
    `select * from shifts where guard_id = $1 and status = 'BREAK' order by created_at desc limit 1`,
    [req.user.userId]
  );
  const shift = shiftResult.rows[0];
  if (!shift) return res.status(409).json({ error: 'Not currently on break' });

  const breakResult = await query(
    `select * from breaks where shift_id = $1 and ended_at is null order by started_at desc limit 1`,
    [shift.id]
  );
  const openBreak = breakResult.rows[0];
  if (!openBreak) return res.status(409).json({ error: 'No open break found' });

  const ended = await query(`update breaks set ended_at = now() where id = $1 returning *`, [openBreak.id]);
  const breakMs = new Date(ended.rows[0].ended_at) - new Date(ended.rows[0].started_at);

  await query(
    `update shifts set status='ON', total_break_ms = total_break_ms + $2 where id = $1`,
    [shift.id, breakMs]
  );

  await query(
    `insert into activity_log_entries (site_id, guard_id, type, title) values ($1,$2,'break',$3)`,
    [req.user.siteId, req.user.userId, `${req.user.name} ended break (${Math.round(breakMs / 60000)} min)`]
  );

  publish(req.user.siteId, { type: 'fleet', payload: { guardId: req.user.userId, guardName: req.user.name, status: 'ON', event: 'break-end' } });
  res.json(ended.rows[0]);
});

// POST /shifts/location — periodic GPS ping while on an open shift. This
// is what makes the Command Portal's live map actually live: every ping
// updates the guard's last known position and pushes it to any connected
// dispatcher over the fleet stream.
router.post('/location', async (req, res) => {
  const { latitude, longitude, accuracyM } = req.body || {};
  if (latitude == null || longitude == null) {
    return res.status(400).json({ error: 'latitude and longitude are required' });
  }

  const open = await query(
    `select id from shifts where guard_id = $1 and status in ('ON','BREAK') order by created_at desc limit 1`,
    [req.user.userId]
  );
  const shift = open.rows[0];
  if (!shift) return res.status(409).json({ error: 'No open shift' });

  await query(
    `update shifts set last_latitude = $1, last_longitude = $2, last_accuracy_m = $3, last_location_at = now() where id = $4`,
    [latitude, longitude, accuracyM ?? null, shift.id]
  );

  publish(req.user.siteId, {
    type: 'location',
    payload: { guardId: req.user.userId, guardName: req.user.name, latitude, longitude, accuracyM, at: new Date().toISOString() },
  });

  const geofenceResult = await query(`select * from geofences where site_id = $1 and active = true`, [req.user.siteId]);
  const violations = checkGeofences(req.user.userId, latitude, longitude, geofenceResult.rows);

  for (const v of violations) {
    await query(
      `insert into geofence_events (site_id, guard_id, geofence_id, event_type, latitude, longitude) values ($1,$2,$3,$4,$5,$6)`,
      [req.user.siteId, req.user.userId, v.geofence.id, v.eventType, latitude, longitude]
    );

    const title = v.eventType === 'entered_restricted'
      ? `Geofence violation: entered restricted area "${v.geofence.name}"`
      : `Geofence violation: left authorized area "${v.geofence.name}"`;

    await query(
      `insert into activity_log_entries (site_id, guard_id, type, title, meta) values ($1,$2,'geofence',$3,$4)`,
      [req.user.siteId, req.user.userId, title, `${req.user.name} · ${latitude.toFixed(5)}, ${longitude.toFixed(5)}`]
    );

    publish(req.user.siteId, {
      type: 'geofence',
      payload: { guardName: req.user.name, title, eventType: v.eventType, geofenceName: v.geofence.name },
    });
  }

  res.status(204).end();
});

// GET /shifts/attendance/today — for the command portal
router.get('/attendance/today', async (req, res) => {
  const { rows } = await query(
    `select s.*, u.name as guard_name, u.badge_number
     from shifts s
     join users u on u.id = s.guard_id
     where s.site_id = $1 and s.created_at::date = current_date
     order by s.created_at desc`,
    [req.user.siteId]
  );
  res.json(rows);
});

module.exports = router;

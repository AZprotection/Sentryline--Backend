const express = require('express');
const { query } = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth);

router.get('/', async (req, res) => {
  const { rows } = await query(
    `select m.*, u.name as sender_name, u.role as sender_role
     from messages m join users u on u.id = m.sender_id
     where m.site_id = $1 order by m.created_at asc limit 200`,
    [req.user.siteId]
  );
  res.json(rows);
});

router.post('/', async (req, res) => {
  const { body } = req.body || {};
  if (!body) return res.status(400).json({ error: 'body is required' });

  const { rows } = await query(
    `insert into messages (sender_id, site_id, body) values ($1,$2,$3) returning *`,
    [req.user.userId, req.user.siteId, body]
  );
  res.status(201).json(rows[0]);
});

module.exports = router;

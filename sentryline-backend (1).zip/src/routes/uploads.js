const express = require('express');
const crypto = require('crypto');
const { requireAuth } = require('../middleware/auth');
const storage = require('../services/storage');

const router = express.Router();
router.use(requireAuth);

const EXTENSION_BY_TYPE = {
  'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp',
  'video/webm': 'webm', 'video/mp4': 'mp4',
  'audio/webm': 'webm', 'audio/mp4': 'm4a',
};

// POST /uploads/presign  { contentType: "image/png" }
// Returns a short-lived URL the client PUTs the file to directly, and the
// public URL to save as the attachment's `url` once that upload finishes.
// Falls back to a 501 if object storage isn't configured — the frontend
// then uses inline base64 attachments instead (see api.js).
router.post('/presign', async (req, res) => {
  if (!storage.isConfigured()) {
    return res.status(501).json({ error: 'Object storage is not configured on this server' });
  }

  const { contentType } = req.body || {};
  if (!contentType) return res.status(400).json({ error: 'contentType is required' });

  const ext = EXTENSION_BY_TYPE[contentType] || 'bin';
  const key = `attachments/${req.user.siteId}/${new Date().toISOString().slice(0, 10)}/${crypto.randomUUID()}.${ext}`;

  const { uploadUrl, publicUrl } = await storage.getUploadUrl(key, contentType);
  res.json({ uploadUrl, publicUrl });
});

module.exports = router;

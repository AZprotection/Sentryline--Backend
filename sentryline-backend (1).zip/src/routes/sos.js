const express = require('express');
const { query } = require('../db');
const { requireAuth } = require('../middleware/auth');
const { publish } = require('../pubsub');

const router = express.Router();
router.use(requireAuth);

router.get('/active', async (req, res) => {
  const { rows } = await query(`select * from sos_events where site_id = $1 and status = 'ACTIVE'`, [req.user.siteId]);
  res.json(rows);
});

router.post('/trigger', async (req, res) => {
  const { latitude, longitude } = req.body || {};
  const { rows } = await query(
    `insert into sos_events (site_id, guard_id, status, latitude, longitude) values ($1,$2,'ACTIVE',$3,$4) returning *`,
    [req.user.siteId, req.user.userId, latitude ?? null, longitude ?? null]
  );
  const event = rows[0];

  await query(
    `insert into activity_log_entries (site_id, guard_id, type, title, meta) values ($1,$2,'sos',$3,$4)`,
    [req.user.siteId, req.user.userId, `SOS triggered by ${req.user.name}`,
      latitude != null ? `${latitude.toFixed(5)}, ${longitude.toFixed(5)}` : 'Location unavailable']
  );

  publish(req.user.siteId, { type: 'sos', payload: { ...event, guardName: req.user.name } });
  res.status(201).json(event);
});

router.post('/clear', async (req, res) => {
  const { rows } = await query(
    `update sos_events set status = 'CLEARED', cleared_at = now()
     where id = (
       select id from sos_events where guard_id = $1 and status = 'ACTIVE' order by triggered_at desc limit 1
     )
     returning *`,
    [req.user.userId]
  );
  const event = rows[0];
  if (event) {
    await query(
      `insert into activity_log_entries (site_id, guard_id, type, title) values ($1,$2,'sos-clear',$3)`,
      [req.user.siteId, req.user.userId, `All clear confirmed by ${req.user.name}`]
    );
    publish(req.user.siteId, { type: 'sos-clear', payload: { ...event, guardName: req.user.name } });
  }
  res.json(event || null);
});

module.exports = router;

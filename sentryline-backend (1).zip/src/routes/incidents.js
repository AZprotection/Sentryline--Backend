const express = require('express');
const { query, pool } = require('../db');
const { requireAuth } = require('../middleware/auth');
const { publish } = require('../pubsub');

const router = express.Router();
router.use(requireAuth);

// GET /incidents — most recent first
router.get('/', async (req, res) => {
  const { rows } = await query(
    `select i.id, i.site_id, i.reported_by_id, i.type, i.location, i.description, i.severity, i.created_at,
      u.name as reported_by_name,
      coalesce(json_agg(json_build_object('id',a.id::text,'type',a.type,'url',a.url))
        filter (where a.id is not null), '[]') as attachments
     from incidents i
     join users u on u.id = i.reported_by_id
     left join attachments a on a.incident_id = i.id
     where i.site_id = $1
     group by i.id, i.site_id, i.reported_by_id, i.type, i.location, i.description, i.severity, i.created_at, u.name
     order by i.created_at desc`,
    [req.user.siteId]
  );
  res.json(rows);
});

// POST /incidents  { type, location, description, severity, attachments: [{type, url}] }
// Attachment URLs should point to your object storage (S3/R2/Supabase Storage)
// in production. For local/demo use, a data: URL works too.
router.post('/', async (req, res) => {
  const { type, location, description, severity, attachments } = req.body || {};
  if (!location || !description) {
    return res.status(400).json({ error: 'location and description are required' });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const incidentResult = await client.query(
      `insert into incidents (site_id, reported_by_id, type, location, description, severity)
       values ($1,$2,$3,$4,$5,$6) returning *`,
      [req.user.siteId, req.user.userId, type || 'Other', location, description, severity || 'MEDIUM']
    );
    const incident = incidentResult.rows[0];

    for (const att of attachments || []) {
      await client.query(
        `insert into attachments (type, url, incident_id) values ($1,$2,$3)`,
        [String(att.type).toUpperCase(), att.url, incident.id]
      );
    }

    await client.query(
      `insert into activity_log_entries (site_id, guard_id, type, title, meta)
       values ($1,$2,'incident',$3,$4)`,
      [req.user.siteId, req.user.userId, `${incident.severity} incident: ${incident.type}`, incident.location]
    );

    await client.query('COMMIT');
    publish(req.user.siteId, {
      type: 'incident',
      payload: { guardName: req.user.name, type: incident.type, severity: incident.severity, location: incident.location },
    });
    res.status(201).json(incident);
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
});

module.exports = router;

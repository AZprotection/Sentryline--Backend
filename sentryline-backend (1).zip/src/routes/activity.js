const express = require('express');
const { query, pool } = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth);

// GET /activity?date=YYYY-MM-DD — defaults to today, for the guard app
// and the command portal's Daily Activity Report tab.
router.get('/', async (req, res) => {
  const date = req.query.date || new Date().toISOString().slice(0, 10);
  const { rows } = await query(
    `select e.id, e.site_id, e.guard_id, e.type, e.title, e.meta, e.created_at,
      u.name as guard_name,
      coalesce(json_agg(json_build_object('id',a.id::text,'type',a.type,'url',a.url))
        filter (where a.id is not null), '[]') as attachments
     from activity_log_entries e
     join users u on u.id = e.guard_id
     left join attachments a on a.activity_log_entry_id = e.id
     where e.site_id = $1 and e.created_at::date = $2
     group by e.id, e.site_id, e.guard_id, e.type, e.title, e.meta, e.created_at, u.name
     order by e.created_at asc`,
    [req.user.siteId, date]
  );
  res.json(rows);
});

// POST /activity  { title, meta, attachments: [{type, url}] } — manual field note
router.post('/', async (req, res) => {
  const { title, meta, attachments } = req.body || {};
  if (!title && !(attachments || []).length) {
    return res.status(400).json({ error: 'title or at least one attachment is required' });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const entryResult = await client.query(
      `insert into activity_log_entries (site_id, guard_id, type, title, meta)
       values ($1,$2,'note',$3,$4) returning *`,
      [req.user.siteId, req.user.userId, title || 'Media attachment added', meta || null]
    );
    const entry = entryResult.rows[0];

    for (const att of attachments || []) {
      await client.query(
        `insert into attachments (type, url, activity_log_entry_id) values ($1,$2,$3)`,
        [String(att.type).toUpperCase(), att.url, entry.id]
      );
    }

    await client.query('COMMIT');
    res.status(201).json(entry);
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
});

module.exports = router;

const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { query } = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth);

// GET /users — every guard/admin on this site, for admin management screens.
// Never returns password_hash.
router.get('/', requireRole('ADMIN'), async (req, res) => {
  const { rows } = await query(
    `select id, name, badge_number, email, phone, role, created_at from users where site_id = $1 order by created_at asc`,
    [req.user.siteId]
  );
  res.json(rows);
});

// POST /users  { name, badgeNumber?, email?, phone?, password, role }
// Onboards a new guard or admin. At least one of badgeNumber/email is
// required since either can be used to log in.
router.post('/', requireRole('ADMIN'), async (req, res) => {
  const { name, badgeNumber, email, phone, password, role } = req.body || {};
  if (!name || !password) return res.status(400).json({ error: 'name and password are required' });
  if (!badgeNumber && !email) return res.status(400).json({ error: 'badgeNumber or email is required, to log in with' });
  if (password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters' });
  if (role && !['GUARD', 'ADMIN'].includes(role)) return res.status(400).json({ error: "role must be 'GUARD' or 'ADMIN'" });

  const passwordHash = await bcrypt.hash(password, 10);
  try {
    const { rows } = await query(
      `insert into users (site_id, name, badge_number, email, phone, password_hash, role)
       values ($1,$2,$3,$4,$5,$6,$7) returning id, name, badge_number, email, phone, role, created_at`,
      [req.user.siteId, name, badgeNumber || null, email || null, phone || null, passwordHash, role || 'GUARD']
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    if (err.code === '23505') { // unique_violation — badge or email already in use
      return res.status(409).json({ error: 'That badge number or email is already registered' });
    }
    throw err;
  }
});

// DELETE /users/:id — deactivate, don't hard-delete (preserves their history:
// past shifts, incidents, activity log entries all reference this user).
router.delete('/:id', requireRole('ADMIN'), async (req, res) => {
  if (req.params.id === req.user.userId) {
    return res.status(400).json({ error: "You can't remove your own account" });
  }
  // A real bcrypt hash of an unguessable random value — not a malformed
  // string — so login attempts fail cleanly through the normal
  // bcrypt.compare() path instead of risking an edge case with bad hash
  // formats.
  const lockedHash = await bcrypt.hash(crypto.randomUUID(), 10);
  await query(
    `update users set password_hash = $1, badge_number = null, email = null
     where id = $2 and site_id = $3`,
    [lockedHash, req.params.id, req.user.siteId]
  );
  res.status(204).end();
});

module.exports = router;

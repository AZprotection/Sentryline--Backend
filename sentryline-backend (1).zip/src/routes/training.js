const express = require('express');
const { query } = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth);

router.get('/', async (req, res) => {
  const { rows } = await query(
    `select t.*, u.name as guard_name
     from trainings t join users u on u.id = t.guard_id
     where t.site_id = $1
     order by u.name asc, t.course asc`,
    [req.user.siteId]
  );
  res.json(rows);
});

router.post('/', requireRole('ADMIN'), async (req, res) => {
  const { guardId, course, pct, status } = req.body || {};
  if (!guardId || !course) return res.status(400).json({ error: 'guardId and course are required' });
  const { rows } = await query(
    `insert into trainings (site_id, guard_id, course, pct, status) values ($1,$2,$3,$4,$5) returning *`,
    [req.user.siteId, guardId, course, pct || 0, status || 'DUE']
  );
  res.status(201).json(rows[0]);
});

router.patch('/:id', async (req, res) => {
  const { pct, status } = req.body || {};
  const { rows } = await query(
    `update trainings set pct = coalesce($1, pct), status = coalesce($2, status), updated_at = now()
     where id = $3 and site_id = $4 returning *`,
    [pct ?? null, status ?? null, req.params.id, req.user.siteId]
  );
  if (!rows[0]) return res.status(404).json({ error: 'Training record not found' });
  res.json(rows[0]);
});

module.exports = router;

const express = require('express');
const { query } = require('../db');
const { requireAuth } = require('../middleware/auth');
const { sendEmail } = require('../services/email');
const { sendSms } = require('../services/sms');

const router = express.Router();
router.use(requireAuth);

router.get('/', async (req, res) => {
  const { rows } = await query(
    `select * from client_reports where site_id = $1 order by created_at desc`,
    [req.user.siteId]
  );
  res.json(rows);
});

// POST /reports/send — compiles today's numbers and emails/texts every
// contact on file for this site. Uses RESEND_API_KEY / TWILIO_* if set,
// otherwise logs a simulated send so this works without keys in dev.
router.post('/send', async (req, res) => {
  const siteId = req.user.siteId;

  const [checkpointsRes, incidentsRes, visitorsRes, contactsRes, siteRes] = await Promise.all([
    query(
      `select count(*) filter (where status='DONE') as done, count(*) as total
       from checkpoint_scans cs join checkpoints c on c.id = cs.checkpoint_id
       where c.site_id = $1 and cs.created_at::date = current_date`,
      [siteId]
    ),
    query(`select count(*) from incidents where site_id = $1 and created_at::date = current_date`, [siteId]),
    query(`select count(*) from visitors where site_id = $1 and check_in_at::date = current_date`, [siteId]),
    query(`select * from client_contacts where site_id = $1`, [siteId]),
    query(`select name from sites where id = $1`, [siteId]),
  ]);

  const done = checkpointsRes.rows[0].done;
  const total = checkpointsRes.rows[0].total;
  const incidentCount = incidentsRes.rows[0].count;
  const visitorCount = visitorsRes.rows[0].count;
  const siteName = siteRes.rows[0]?.name || 'Site';

  const summary = `${done}/${total} checkpoints, ${incidentCount} incident(s), ${visitorCount} visitor(s)`;
  const html = `<h2>${siteName} — nightly patrol summary</h2><p>${summary}</p>`;

  const results = [];
  for (const contact of contactsRes.rows) {
    if (contact.email) {
      results.push(await sendEmail({ to: contact.email, subject: `${siteName} — nightly patrol summary`, html }));
    }
    if (contact.phone) {
      results.push(await sendSms({ to: contact.phone, body: `${siteName}: ${summary}` }));
    }
  }

  const { rows } = await query(
    `insert into client_reports (site_id, summary, sent_via) values ($1,$2,$3) returning *`,
    [siteId, summary, contactsRes.rows.length ? 'email+sms' : 'none-no-contacts']
  );

  res.status(201).json({ report: rows[0], deliveries: results });
});

module.exports = router;

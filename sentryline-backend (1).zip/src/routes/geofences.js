const express = require('express');
const { query } = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth);

router.get('/', async (req, res) => {
  const { rows } = await query(
    `select * from geofences where site_id = $1 and active = true order by created_at asc`,
    [req.user.siteId]
  );
  res.json(rows);
});

// POST /geofences  { name, type: "authorized"|"restricted", centerLatitude, centerLongitude, radiusM }
router.post('/', requireRole('ADMIN'), async (req, res) => {
  const { name, type, centerLatitude, centerLongitude, radiusM } = req.body || {};
  if (!name || !type || centerLatitude == null || centerLongitude == null || !radiusM) {
    return res.status(400).json({ error: 'name, type, centerLatitude, centerLongitude, and radiusM are required' });
  }
  if (!['authorized', 'restricted'].includes(type)) {
    return res.status(400).json({ error: "type must be 'authorized' or 'restricted'" });
  }

  const { rows } = await query(
    `insert into geofences (site_id, name, type, center_latitude, center_longitude, radius_m)
     values ($1,$2,$3,$4,$5,$6) returning *`,
    [req.user.siteId, name, type, centerLatitude, centerLongitude, radiusM]
  );
  res.status(201).json(rows[0]);
});

router.delete('/:id', requireRole('ADMIN'), async (req, res) => {
  await query(`update geofences set active = false where id = $1 and site_id = $2`, [req.params.id, req.user.siteId]);
  res.status(204).end();
});

// GET /geofences/events — recent violations, for the Command Portal
router.get('/events', async (req, res) => {
  const { rows } = await query(
    `select e.id, e.event_type, e.latitude, e.longitude, e.created_at,
       g.name as geofence_name, g.type as geofence_type, u.name as guard_name
     from geofence_events e
     join geofences g on g.id = e.geofence_id
     join users u on u.id = e.guard_id
     where e.site_id = $1
     order by e.created_at desc
     limit 100`,
    [req.user.siteId]
  );
  res.json(rows);
});

module.exports = router;

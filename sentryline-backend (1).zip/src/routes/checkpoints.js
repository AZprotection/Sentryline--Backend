const express = require('express');
const { query } = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');
const { publish } = require('../pubsub');

const router = express.Router();
router.use(requireAuth);

// GET /checkpoints — full list for the caller's site, unlimited count
router.get('/', async (req, res) => {
  const { rows } = await query(
    `select * from checkpoints where site_id = $1 and active = true order by sort_order asc, created_at asc`,
    [req.user.siteId]
  );
  res.json(rows);
});

// POST /checkpoints — admin adds a new checkpoint (no limit per client)
router.post('/', requireRole('ADMIN'), async (req, res) => {
  const { name, zone, nfcTagId, isAssetCheck, postOrder, position } = req.body || {};
  if (!name || !zone) return res.status(400).json({ error: 'name and zone are required' });

  const tagId = nfcTagId || `NFC-${Math.floor(1000 + Math.random() * 9000)}`;
  const sortOrder =
    position === 'start'
      ? -1
      : (await query(`select coalesce(max(sort_order),0)+1 as next from checkpoints where site_id=$1`, [req.user.siteId])).rows[0].next;

  const { rows } = await query(
    `insert into checkpoints (site_id, name, zone, nfc_tag_id, is_asset_check, post_order, sort_order)
     values ($1,$2,$3,$4,$5,$6,$7) returning *`,
    [req.user.siteId, name, zone, tagId, !!isAssetCheck, postOrder || null, sortOrder]
  );
  res.status(201).json(rows[0]);
});

// DELETE /checkpoints/:id — admin removes a checkpoint
router.delete('/:id', requireRole('ADMIN'), async (req, res) => {
  await query(`update checkpoints set active = false where id = $1 and site_id = $2`, [req.params.id, req.user.siteId]);
  res.status(204).end();
});

// POST /checkpoints/:id/scan — guard scans (NFC tap or manual), tied to their open shift
router.post('/:id/scan', async (req, res) => {
  const { latitude, longitude, accuracyM, method, status } = req.body || {};
  const checkpointId = req.params.id;

  const shiftResult = await query(
    `select id from shifts where guard_id = $1 and status in ('ON','BREAK') order by created_at desc limit 1`,
    [req.user.userId]
  );
  const shift = shiftResult.rows[0];
  if (!shift) return res.status(409).json({ error: 'No open shift — clock in before scanning checkpoints' });

  const { rows } = await query(
    `insert into checkpoint_scans (checkpoint_id, shift_id, guard_id, status, scanned_at, latitude, longitude, accuracy_m, method)
     values ($1,$2,$3,$4, now(), $5,$6,$7,$8) returning *`,
    [checkpointId, shift.id, req.user.userId, status || 'DONE', latitude ?? null, longitude ?? null, accuracyM ?? null, method || 'manual']
  );

  await query(
    `insert into activity_log_entries (site_id, guard_id, type, title, meta)
     values ($1,$2,'checkpoint',$3,$4)`,
    [
      req.user.siteId,
      req.user.userId,
      `Checkpoint ${status === 'MISSED' ? 'missed' : 'cleared'}`,
      latitude ? `${latitude.toFixed(5)}, ${longitude.toFixed(5)}` : null,
    ]
  );

  publish(req.user.siteId, {
    type: 'checkpoint',
    payload: { guardId: req.user.userId, guardName: req.user.name, checkpointId, status: status || 'DONE' },
  });

  res.status(201).json(rows[0]);
});

// GET /checkpoints/scans/today — for the command portal's progress view
router.get('/scans/today', async (req, res) => {
  const { rows } = await query(
    `select cs.*, c.name as checkpoint_name, c.zone
     from checkpoint_scans cs
     join checkpoints c on c.id = cs.checkpoint_id
     where c.site_id = $1 and cs.created_at::date = current_date
     order by cs.created_at desc`,
    [req.user.siteId]
  );
  res.json(rows);
});

module.exports = router;

const express = require('express');
const { query } = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth);

router.get('/', async (req, res) => {
  const { rows } = await query(`select * from zones where site_id = $1 order by name asc`, [req.user.siteId]);
  res.json(rows);
});

router.post('/', requireRole('ADMIN'), async (req, res) => {
  const { name, schedule, note } = req.body || {};
  if (!name) return res.status(400).json({ error: 'name is required' });
  const { rows } = await query(
    `insert into zones (site_id, name, schedule, note) values ($1,$2,$3,$4) returning *`,
    [req.user.siteId, name, schedule || null, note || null]
  );
  res.status(201).json(rows[0]);
});

// PATCH /zones/:id/toggle — flips locked/unlocked and logs it to the activity feed
router.patch('/:id/toggle', async (req, res) => {
  const { rows } = await query(
    `update zones set locked = not locked where id = $1 and site_id = $2 returning *`,
    [req.params.id, req.user.siteId]
  );
  const zone = rows[0];
  if (!zone) return res.status(404).json({ error: 'Zone not found' });

  await query(
    `insert into activity_log_entries (site_id, guard_id, type, title, meta) values ($1,$2,'access',$3,$4)`,
    [req.user.siteId, req.user.userId, `${zone.name} ${zone.locked ? 'locked' : 'unlocked'}`, `Zone access changed`]
  );

  res.json(zone);
});

module.exports = router;

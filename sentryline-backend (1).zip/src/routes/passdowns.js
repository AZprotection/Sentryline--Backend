const express = require('express');
const { query } = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth);

// GET /passdowns — most recent first, for the site
router.get('/', async (req, res) => {
  const { rows } = await query(
    `select p.*, fu.name as from_guard_name, tu.name as to_guard_name, au.name as acknowledged_by_name
     from passdowns p
     join users fu on fu.id = p.from_guard_id
     left join users tu on tu.id = p.to_guard_id
     left join users au on au.id = p.acknowledged_by_id
     where p.site_id = $1
     order by p.created_at desc
     limit 100`,
    [req.user.siteId]
  );
  res.json(rows);
});

// POST /passdowns  { message, priority: "normal"|"urgent", toGuardId? }
router.post('/', async (req, res) => {
  const { message, priority, toGuardId } = req.body || {};
  if (!message || !message.trim()) return res.status(400).json({ error: 'message is required' });

  const { rows } = await query(
    `insert into passdowns (site_id, from_guard_id, to_guard_id, message, priority)
     values ($1,$2,$3,$4,$5) returning *`,
    [req.user.siteId, req.user.userId, toGuardId || null, message.trim(), priority === 'urgent' ? 'urgent' : 'normal']
  );

  await query(
    `insert into activity_log_entries (site_id, guard_id, type, title, meta) values ($1,$2,'passdown',$3,$4)`,
    [req.user.siteId, req.user.userId, `Passdown note left by ${req.user.name}`, message.trim().slice(0, 140)]
  );

  res.status(201).json(rows[0]);
});

// POST /passdowns/:id/acknowledge — incoming guard marks it read
router.post('/:id/acknowledge', async (req, res) => {
  const { rows } = await query(
    `update passdowns set acknowledged_at = now(), acknowledged_by_id = $1
     where id = $2 and site_id = $3 returning *`,
    [req.user.userId, req.params.id, req.user.siteId]
  );
  if (!rows[0]) return res.status(404).json({ error: 'Passdown not found' });
  res.json(rows[0]);
});

module.exports = router;

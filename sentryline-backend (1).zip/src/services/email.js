const { Resend } = require('resend');

const resend = process.env.RESEND_API_KEY ? new Resend(process.env.RESEND_API_KEY) : null;

// Sends a real email if RESEND_API_KEY is set; otherwise logs and returns
// a "simulated" result so local dev and demos still work without a key.
async function sendEmail({ to, subject, html }) {
  if (!resend) {
    console.log(`[email:simulated] to=${to} subject="${subject}"`);
    return { simulated: true };
  }
  const result = await resend.emails.send({
    from: process.env.EMAIL_FROM || 'Sentryline <reports@your-verified-domain.com>',
    to,
    subject,
    html,
  });
  return { simulated: false, result };
}

module.exports = { sendEmail };

// Error tracking via Sentry. Works immediately without any setup — errors
// just log to the console. Set SENTRY_DSN to also send them to a real
// Sentry project so you find out about production errors instead of a
// guard telling you the app "just didn't work" three days later.
const Sentry = require('@sentry/node');

const enabled = !!process.env.SENTRY_DSN;

if (enabled) {
  Sentry.init({
    dsn: process.env.SENTRY_DSN,
    environment: process.env.NODE_ENV || 'production',
    tracesSampleRate: 0.1,
  });
}

function captureException(err, context) {
  console.error(err, context || '');
  if (enabled) Sentry.captureException(err, context ? { extra: context } : undefined);
}

module.exports = { Sentry, enabled, captureException };

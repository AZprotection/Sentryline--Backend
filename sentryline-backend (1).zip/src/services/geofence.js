// Geofence violation detection. Geofences here are circles (center point +
// radius) — simple, fast to check, and covers the overwhelming majority
// of real "stay in this lot" / "stay out of this building" use cases.
// Polygon geofences (arbitrary-shaped boundaries) would be a reasonable
// future upgrade if a site's real perimeter isn't well-approximated by a
// circle, but add real complexity (point-in-polygon math) for a benefit
// most sites won't need.
//
// Containment state (which geofences each guard is currently inside) is
// tracked in memory, same as the pub-sub in pubsub.js — fine for a single
// Node process, reset on restart. If you scale to multiple instances,
// this needs to move to a shared store (Redis) same as pubsub would.
const containmentByGuard = new Map(); // guardId -> Set of geofence ids currently inside

function haversineMeters(lat1, lon1, lat2, lon2) {
  const R = 6371000;
  const toRad = (d) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// Given a guard's new position and the site's active geofences, returns
// only the violation-worthy transitions since their last known position:
// entering a restricted zone, or leaving an authorized one. Entering an
// authorized zone or leaving a restricted one isn't a violation, so
// those transitions are tracked (for correct future diffing) but not
// returned as events.
function checkGeofences(guardId, lat, lon, geofences) {
  const previous = containmentByGuard.get(guardId) || new Set();
  const current = new Set();
  const violations = [];

  for (const gf of geofences) {
    const distance = haversineMeters(lat, lon, gf.center_latitude, gf.center_longitude);
    const inside = distance <= gf.radius_m;
    const wasInside = previous.has(gf.id);

    if (inside) current.add(gf.id);

    if (inside && !wasInside && gf.type === 'restricted') {
      violations.push({ geofence: gf, eventType: 'entered_restricted' });
    } else if (!inside && wasInside && gf.type === 'authorized') {
      violations.push({ geofence: gf, eventType: 'exited_authorized' });
    }
  }

  containmentByGuard.set(guardId, current);
  return violations;
}

// Exposed for tests — lets a test reset state between runs without
// restarting the process.
function _resetContainment() {
  containmentByGuard.clear();
}

module.exports = { checkGeofences, haversineMeters, _resetContainment };

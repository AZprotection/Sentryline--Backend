// Object storage for incident/activity attachments — photos, videos, and
// voice memos. Works with any S3-compatible provider: AWS S3, Cloudflare
// R2, or Supabase Storage all speak this same API, just with different
// endpoint URLs.
//
// Without STORAGE_* env vars set, this module is inert and the app falls
// back to storing attachments as base64 data URLs directly in Postgres
// (see sql/schema.sql — attachments.url is just a text column, so either
// approach fits it). That's fine for a small pilot; base64-in-Postgres
// bloats the database fast once guards are regularly attaching photos and
// videos, so switch this on before a real rollout.
const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');
const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');

const configured = !!(process.env.STORAGE_BUCKET && process.env.STORAGE_ACCESS_KEY_ID && process.env.STORAGE_SECRET_ACCESS_KEY);

let client = null;
if (configured) {
  client = new S3Client({
    region: process.env.STORAGE_REGION || 'auto',
    endpoint: process.env.STORAGE_ENDPOINT || undefined, // set for R2/Supabase; omit for real AWS S3
    credentials: {
      accessKeyId: process.env.STORAGE_ACCESS_KEY_ID,
      secretAccessKey: process.env.STORAGE_SECRET_ACCESS_KEY,
    },
    forcePathStyle: !!process.env.STORAGE_ENDPOINT, // required by R2 and most S3-compatible providers
  });
}

function isConfigured() {
  return configured;
}

// Returns a short-lived signed URL the client can PUT a file to directly
// (the file never passes through this server), plus the public URL it'll
// be reachable at afterward — assuming the bucket is public-read, or that
// STORAGE_PUBLIC_BASE_URL points at a CDN/proxy in front of it.
async function getUploadUrl(key, contentType) {
  if (!configured) throw new Error('Object storage is not configured');

  const command = new PutObjectCommand({
    Bucket: process.env.STORAGE_BUCKET,
    Key: key,
    ContentType: contentType,
  });

  const uploadUrl = await getSignedUrl(client, command, { expiresIn: 300 });
  const publicBase = process.env.STORAGE_PUBLIC_BASE_URL || `https://${process.env.STORAGE_BUCKET}.s3.amazonaws.com`;
  const publicUrl = `${publicBase.replace(/\/$/, '')}/${key}`;

  return { uploadUrl, publicUrl };
}

module.exports = { isConfigured, getUploadUrl };

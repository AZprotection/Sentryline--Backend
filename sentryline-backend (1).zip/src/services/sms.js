const twilio = require('twilio');

const client =
  process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN
    ? twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN)
    : null;

// Sends a real text if Twilio credentials are set; otherwise logs and
// returns a "simulated" result so local dev and demos still work.
async function sendSms({ to, body }) {
  if (!client) {
    console.log(`[sms:simulated] to=${to} body="${body}"`);
    return { simulated: true };
  }
  const message = await client.messages.create({
    from: process.env.TWILIO_FROM_NUMBER,
    to,
    body,
  });
  return { simulated: false, sid: message.sid };
}

module.exports = { sendSms };

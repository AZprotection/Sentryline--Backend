# Deploying Sentryline — exact steps

Everything code-related is already built and tested. What's left needs
your own accounts (email verification, billing) — nothing I can do on
your behalf. This should take about 10–15 minutes.

## Cost note up front

The blueprint below (`render.yaml`) defaults to Render's **Starter** web
service (~$7/mo) and **Basic-256mb** Postgres (~$6/mo, roughly $13/mo
total). This is deliberate: Render's free tier spins a service down after
15 minutes of inactivity, which would silently drop the live SSE
connections that make the fleet map real-time, and cause a slow "cold
start" delay on a guard's clock-in or SOS press — not what you want for a
live security app. If you just want to demo this for free first, see
"Testing on the free tier" near the bottom before committing to a paid
plan.

## 1. Push this code to GitHub (5 min)

You need a Git repository Render can pull from.

1. Go to **github.com/new**, create a repository (public or private — either works), don't initialize it with a README.
2. On your own machine, with this `backend` folder:
   ```bash
   cd backend
   git init
   git add .
   git commit -m "Sentryline backend"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
   git push -u origin main
   ```

## 2. Deploy the Blueprint on Render (3 min)

1. Go to **dashboard.render.com**, sign up or log in.
2. Click **New +** → **Blueprint**.
3. Connect your GitHub account if prompted, then select the repo you just pushed.
4. Render reads `render.yaml` and shows you a preview: one web service (`sentryline-api`) and one Postgres database (`sentryline-db`).
5. You'll be prompted to fill in a few values it can't generate itself — for now, leave `RESEND_API_KEY`, `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, and `TWILIO_FROM_NUMBER` **blank**. The app runs fine without them (emails/texts just log instead of sending — you'll add real values in step 4).
6. Click **Deploy Blueprint**.
7. Wait a few minutes for the build. When it's done, your API is live at something like `https://sentryline-api.onrender.com` — copy that URL.

## 3. Seed demo data (2 min)

The database is empty until you seed it. From your own machine:

```bash
cd backend
npm install
```

Get your database's **External Connection String** from the Render dashboard (click `sentryline-db` → Connections). Then:

```bash
DATABASE_URL="paste-the-external-connection-string-here" npm run seed
```

This creates a demo site, two guards (`GS-2471`, `GS-1980`), an admin, and checkpoints. It prints the login credentials when done. Run this once — running it again creates duplicate demo data, so don't repeat it.

## 4. Get real email and text delivery working (5 min each, optional but recommended)

**Email — Resend:**
1. Go to **resend.com**, sign up.
2. Add and verify a sending domain (Resend walks you through adding a DNS record), or use their shared test domain to start.
3. Go to **API Keys**, create one, copy it.
4. In the Render dashboard, open `sentryline-api` → **Environment**, paste it into `RESEND_API_KEY`, and update `EMAIL_FROM` to match your verified domain.

**Text messages — Twilio:**
1. Go to **twilio.com**, sign up.
2. Buy a phone number (Twilio's console walks you through this — small monthly cost).
3. From the Twilio Console dashboard, copy your **Account SID** and **Auth Token**.
4. In the Render dashboard, paste those into `TWILIO_ACCOUNT_SID` and `TWILIO_AUTH_TOKEN`, and your purchased number into `TWILIO_FROM_NUMBER` (in `+15551234567` format).

Render redeploys automatically when you save environment variable changes.

## 5. Point the frontend at your live backend (1 min)

Open `api.js` in the `sentryline-pwa` package and change:

```js
const API_BASE_URL = '';
```

to:

```js
const API_BASE_URL = 'https://sentryline-api.onrender.com';
```

(using your actual Render URL from step 2). Then redeploy the frontend the same way you did originally (Netlify drag-and-drop, or push to your existing site).

## You're live

Open the frontend URL on a phone, log in with one of the seeded badge
numbers and `patrol123`, and everything — checkpoints, incidents, clock
in/out, live fleet tracking — is now backed by a real, persistent
database instead of resetting on every page reload.

## Testing on the free tier first (optional)

If you want to try this with zero cost before committing to a paid plan,
edit `render.yaml` before deploying and change:

```yaml
plan: starter   →   plan: free      # under services
plan: basic-256mb   →   plan: free  # under databases
```

Everything works the same way, with two caveats: the API sleeps after 15
minutes of no traffic (the next request wakes it up after a ~30-60 second
delay), and Render's free Postgres databases expire after a fixed period
and need to be recreated. Fine for a demo or pilot with a few guards; not
something to leave running unattended for a real deployment.
